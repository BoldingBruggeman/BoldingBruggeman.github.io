editscenario and nml2xml
========================
Convert .xml based configuration to Fortran namelists (and vice versa)

To make a wheel
---------------
pip wheel .

To install a wheel
------------------
pip install <--upgrade> editscenario-0.1-py2-none-any.whl

Add options -v -v -v to see where files are installed

Add --user to install in default *user* directory


